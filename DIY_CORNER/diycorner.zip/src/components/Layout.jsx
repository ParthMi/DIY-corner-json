import React, { useState } from 'react'
import Navbar from './Navbar'
import Index from './Index';
import Footer from './Footer'
import { useParams } from 'react-router';
import Blog from './Blog';

const Layout = () => {
  const { type,idea } = useParams();
  const [search,setSearch]=useState("");
  // console.log(idea)
  return (
    <>
    <Navbar onSearch={setSearch}/>
    {idea ===undefined ?
        <Index search={search}/>
        :<Blog/>
    }
    <Footer/>
    </>
  )
}

export default Layout
